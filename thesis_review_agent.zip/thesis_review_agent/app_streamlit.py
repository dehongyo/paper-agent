from __future__ import annotations

import tempfile
import sys
from pathlib import Path

import streamlit as st
import yaml

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from thesis_review_agent.extractor import load_document
from thesis_review_agent.checks import RuleChecker
from thesis_review_agent.llm_client import LLMClient
from thesis_review_agent.prompts import REVIEW_SYSTEM_PROMPT, build_review_prompt
from thesis_review_agent.reporter import findings_to_markdown, build_report
from thesis_review_agent.models import ReviewResult


st.set_page_config(page_title="硕士论文评审 Agent", layout="wide")
st.title("硕士论文评审与格式检查 Agent")

st.markdown(
    "上传待评审论文和评审模板后，系统会自动检查格式、排版、图表、语言表达、符号解释和参考文献等问题。"
)

paper_file = st.file_uploader("上传论文（PDF 或 DOCX）", type=["pdf", "docx"])
template_file = st.file_uploader("上传评审模板（txt，可选）", type=["txt"])
use_llm = st.checkbox("启用 LLM 综合评审", value=True)

cfg_path = ROOT / "examples" / "config.yaml"
cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) if cfg_path.exists() else {}

if st.button("生成评审报告", type="primary"):
    if not paper_file:
        st.warning("请先上传论文文件。")
        st.stop()

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        paper_path = tmpdir / paper_file.name
        paper_path.write_bytes(paper_file.getvalue())

        template_text = ""
        template_path = ""
        if template_file:
            template_path = str(tmpdir / template_file.name)
            Path(template_path).write_bytes(template_file.getvalue())
            template_text = Path(template_path).read_text(encoding="utf-8", errors="ignore")
        else:
            default_template = ROOT / "examples" / "review_template.txt"
            template_path = str(default_template)
            template_text = default_template.read_text(encoding="utf-8") if default_template.exists() else ""

        with st.spinner("正在读取论文并执行规则检查..."):
            doc = load_document(str(paper_path))
            checker = RuleChecker(cfg)
            rule_findings = checker.run_all(doc)
            result = ReviewResult(rule_findings=rule_findings)

        if use_llm:
            llm = LLMClient()
            if llm.available:
                with st.spinner("正在调用 LLM 生成综合评审意见..."):
                    prompt = build_review_prompt(
                        paper_text=doc.sample_text(max_pages=int(cfg.get("max_pages_for_llm", 35))),
                        template_text=template_text,
                        rule_findings_markdown=findings_to_markdown(rule_findings[:20]),
                    )
                    result.raw_llm_text = llm.complete(REVIEW_SYSTEM_PROMPT, prompt)
            else:
                st.warning("未检测到 OPENAI_API_KEY，已跳过 LLM 综合评审。")

        report = build_report(doc, result, template_path=template_path)
        st.success("报告生成完成。")
        st.download_button(
            label="下载 Markdown 报告",
            data=report.encode("utf-8"),
            file_name="review_report.md",
            mime="text/markdown",
        )
        st.markdown(report)
