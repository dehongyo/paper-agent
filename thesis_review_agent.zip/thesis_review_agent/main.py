from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer
import yaml
from rich.console import Console
from rich.panel import Panel

# 允许直接从源码目录运行
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from thesis_review_agent.extractor import load_document
from thesis_review_agent.checks import RuleChecker
from thesis_review_agent.llm_client import LLMClient
from thesis_review_agent.models import ReviewResult
from thesis_review_agent.prompts import REVIEW_SYSTEM_PROMPT, build_review_prompt
from thesis_review_agent.reporter import findings_to_markdown, build_report, save_report

app = typer.Typer(help="硕士论文评审与格式检查 Agent")
console = Console()


def load_config(path: Optional[str]) -> dict:
    if not path:
        default = ROOT / "examples" / "config.yaml"
        path = str(default) if default.exists() else ""
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        return {}
    return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


@app.command()
def review(
    paper: str = typer.Option(..., "--paper", "-p", help="待评审论文路径，支持 PDF / DOCX"),
    template: str = typer.Option("examples/review_template.txt", "--template", "-t", help="评审模板路径"),
    output: str = typer.Option("outputs/review_report.md", "--output", "-o", help="输出 Markdown 报告路径"),
    config: Optional[str] = typer.Option(None, "--config", "-c", help="配置文件路径"),
    no_llm: bool = typer.Option(False, "--no-llm", help="只运行规则检查，不调用大模型"),
):
    """生成硕士论文评审辅助报告。"""
    cfg = load_config(config)

    console.print(Panel.fit("正在读取论文...", title="Thesis Review Agent"))
    doc = load_document(paper)

    checker = RuleChecker(cfg)
    rule_findings = checker.run_all(doc)

    template_text = Path(template).read_text(encoding="utf-8") if Path(template).exists() else ""
    result = ReviewResult(rule_findings=rule_findings)

    if not no_llm:
        llm = LLMClient()
        if llm.available:
            console.print("正在调用 LLM 生成综合评审意见...")
            max_pages = int(cfg.get("max_pages_for_llm", 35))
            paper_text = doc.sample_text(max_pages=max_pages)
            prompt = build_review_prompt(
                paper_text=paper_text,
                template_text=template_text,
                rule_findings_markdown=findings_to_markdown(rule_findings[:20]),
            )
            result.raw_llm_text = llm.complete(REVIEW_SYSTEM_PROMPT, prompt)
        else:
            console.print("[yellow]未检测到 OPENAI_API_KEY，已跳过 LLM 深度评审，仅输出规则检查结果。[/yellow]")

    report = build_report(doc, result, template_path=template)
    save_report(report, output)

    console.print(Panel.fit(f"报告已生成：{output}", title="完成"))


if __name__ == "__main__":
    app()
