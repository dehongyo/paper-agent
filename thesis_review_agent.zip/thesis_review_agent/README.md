# 硕士论文评审与格式检查 Agent

这是一个面向“硕士毕业论文初步评审”的本地 Python Agent 示例项目。它可以读取 PDF / DOCX 论文与评审模板，自动生成：

1. 总体评价段落；
2. 格式、排版、图表、语言表达、符号解释、参考文献等表面问题清单；
3. 2–3 条内容层面的修改建议；
4. 尽量带页码、章节或关键词证据的 Markdown 评审报告。

> 注意：该项目用于辅助初审，输出结果需要人工复核，尤其是页码、公式、图表编号和引用问题。

---

## 1. 项目结构

```text
thesis_review_agent/
├─ main.py                         # 命令行入口
├─ app_streamlit.py                 # 简单网页界面
├─ requirements.txt
├─ .env.example
├─ examples/
│  ├─ review_template.txt           # 评审意见模板
│  └─ config.yaml                   # 检查参数配置
├─ outputs/                         # 默认输出目录
└─ src/thesis_review_agent/
   ├─ extractor.py                  # PDF/DOCX 文本与图像信息提取
   ├─ checks.py                     # 规则检查器
   ├─ llm_client.py                 # LLM 调用封装
   ├─ models.py                     # 数据结构
   ├─ prompts.py                    # 提示词
   └─ reporter.py                   # 报告生成
```

---

## 2. 安装

建议使用 Python 3.10 或以上版本。

```bash
cd thesis_review_agent
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

---

## 3. 配置 API Key

复制 `.env.example` 为 `.env`，填入你的大模型 API Key。

```bash
copy .env.example .env
```

`.env` 示例：

```bash
OPENAI_API_KEY=你的API_KEY
OPENAI_BASE_URL=
LLM_MODEL=gpt-4o-mini
```

如果你只想先运行规则检查，也可以不配置 API Key。此时程序会跳过 LLM 深度评审，只输出规则检查报告。

---

## 4. 命令行使用

```bash
python main.py review ^
  --paper "D:\论文\待评审论文.pdf" ^
  --template "examples\review_template.txt" ^
  --output "outputs\review_report.md"
```

macOS / Linux 写法：

```bash
python main.py review \
  --paper "/path/to/thesis.pdf" \
  --template "examples/review_template.txt" \
  --output "outputs/review_report.md"
```

运行后会生成 Markdown 格式评审报告。

---

## 5. 网页界面使用

```bash
streamlit run app_streamlit.py
```

然后在网页里上传论文和模板，点击生成报告即可。

---

## 6. 适合检查的问题类型

本 Agent 主要适合发现以下问题：

- 图表清晰度不足；
- 图表编号、标题、引用不规范；
- 摘要、引言、方法、实验、结论等结构是否完整；
- 公式变量是否存在“出现但未解释”的风险；
- 专业缩写是否存在首次出现未定义问题；
- 参考文献引用格式是否不统一；
- 章节安排是否存在“介绍性内容过多、与本文工作结合不足”的问题；
- 语言表达是否存在重复、口语化、不严谨等问题。

---

## 7. 输出示例

```markdown
# 硕士论文评审辅助报告

## 一、总体评价

该论文围绕……开展研究，选题具有一定理论意义和工程应用价值……

## 二、格式、表达与排版问题

| 位置 | 问题类型 | 具体问题 | 修改建议 |
|---|---|---|---|
| 第 12 页 图 3 | 图表规范 | 图像分辨率偏低，局部文字不清晰 | 建议提高图片分辨率并统一图中文字字号 |

## 三、内容层面问题

1. 第三章算法部分对状态空间和动作空间说明不够充分……
```

---

## 8. 二次开发建议

你可以根据自己的科研方向继续扩展：

- 增加“通信建模检查器”，专门检查信道、SINR、速率公式；
- 增加“强化学习建模检查器”，专门检查状态、动作、奖励、训练流程；
- 增加“参考文献格式检查器”，对 IEEE / GB/T 7714 格式做更严格校验；
- 增加“多论文对比模式”，用于评审论文与相关工作的差异分析。

