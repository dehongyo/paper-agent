from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class PageText:
    page_no: int
    text: str


@dataclass
class FigureInfo:
    page_no: int
    index: int
    width_px: int
    height_px: int
    xref: Optional[int] = None


@dataclass
class DocumentData:
    path: str
    file_type: str
    pages: List[PageText] = field(default_factory=list)
    figures: List[FigureInfo] = field(default_factory=list)

    @property
    def full_text(self) -> str:
        return "\n\n".join(f"[第 {p.page_no} 页]\n{p.text}" for p in self.pages)

    def sample_text(self, max_pages: int = 35) -> str:
        selected = self.pages[:max_pages]
        return "\n\n".join(f"[第 {p.page_no} 页]\n{p.text}" for p in selected)


@dataclass
class Finding:
    location: str
    category: str
    problem: str
    suggestion: str
    evidence: str = ""
    confidence: str = "medium"

    def to_markdown_row(self) -> str:
        def esc(s: str) -> str:
            return (s or "").replace("|", "｜").replace("\n", " ")
        return f"| {esc(self.location)} | {esc(self.category)} | {esc(self.problem)} | {esc(self.suggestion)} | {esc(self.evidence)} | {esc(self.confidence)} |"


@dataclass
class ReviewResult:
    summary: str = ""
    rule_findings: List[Finding] = field(default_factory=list)
    llm_findings: List[Finding] = field(default_factory=list)
    content_suggestions: List[Finding] = field(default_factory=list)
    raw_llm_text: str = ""

    @property
    def all_findings(self) -> List[Finding]:
        return self.rule_findings + self.llm_findings
