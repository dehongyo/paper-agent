from __future__ import annotations

import re
from pathlib import Path
from typing import List

from .models import DocumentData, PageText, FigureInfo


def load_document(path: str) -> DocumentData:
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在：{path}")

    suffix = file_path.suffix.lower()
    if suffix == ".pdf":
        return load_pdf(file_path)
    if suffix == ".docx":
        return load_docx(file_path)

    raise ValueError("目前只支持 PDF 和 DOCX 文件。")


def load_pdf(path: Path) -> DocumentData:
    try:
        import fitz  # PyMuPDF
    except ImportError as exc:
        raise RuntimeError("请先安装 pymupdf：pip install pymupdf") from exc

    doc = fitz.open(str(path))
    pages: List[PageText] = []
    figures: List[FigureInfo] = []

    for i, page in enumerate(doc, start=1):
        text = page.get_text("text") or ""
        text = normalize_text(text)
        pages.append(PageText(page_no=i, text=text))

        for img_idx, img in enumerate(page.get_images(full=True), start=1):
            xref = img[0]
            width = int(img[2]) if len(img) > 2 else 0
            height = int(img[3]) if len(img) > 3 else 0
            figures.append(
                FigureInfo(
                    page_no=i,
                    index=img_idx,
                    width_px=width,
                    height_px=height,
                    xref=xref,
                )
            )

    return DocumentData(
        path=str(path),
        file_type="pdf",
        pages=pages,
        figures=figures,
    )


def load_docx(path: Path) -> DocumentData:
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("请先安装 python-docx：pip install python-docx") from exc

    doc = Document(str(path))
    paras = [normalize_text(p.text) for p in doc.paragraphs if p.text.strip()]

    # DOCX 没有稳定页码，这里按大约 18 段划分为“估计页”
    pages: List[PageText] = []
    page_size = 18
    for start in range(0, len(paras), page_size):
        page_no = start // page_size + 1
        pages.append(PageText(page_no=page_no, text="\n".join(paras[start:start + page_size])))

    return DocumentData(
        path=str(path),
        file_type="docx",
        pages=pages,
        figures=[],
    )


def normalize_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def split_chunks(text: str, chunk_size: int = 3500, overlap: int = 400) -> List[str]:
    if chunk_size <= overlap:
        raise ValueError("chunk_size 必须大于 overlap。")

    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks
