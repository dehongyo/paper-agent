from __future__ import annotations

import re
from collections import Counter
from statistics import mean
from typing import Iterable, List, Dict, Any

from .models import DocumentData, Finding


class RuleChecker:
    """规则检查器：偏向发现可验证的格式、表达、排版和规范问题。"""

    def __init__(self, config: Dict[str, Any] | None = None):
        self.config = config or {}

    def run_all(self, doc: DocumentData) -> List[Finding]:
        findings: List[Finding] = []
        findings.extend(self.check_structure(doc))
        findings.extend(self.check_figures(doc))
        findings.extend(self.check_captions_and_references(doc))
        findings.extend(self.check_abbreviations(doc))
        findings.extend(self.check_formula_symbols(doc))
        findings.extend(self.check_language_surface(doc))
        findings.extend(self.check_reference_section(doc))
        return findings

    def check_structure(self, doc: DocumentData) -> List[Finding]:
        text = doc.full_text
        keywords = self.config.get("section_keywords") or [
            "摘要", "引言", "绪论", "方法", "实验", "仿真", "结论", "参考文献"
        ]
        findings: List[Finding] = []

        missing = [kw for kw in keywords if kw not in text]
        # 只提示常见核心部分，避免过度误报
        important = [kw for kw in ["摘要", "结论", "参考文献"] if kw in missing]
        for kw in important:
            findings.append(Finding(
                location="全文结构",
                category="章节完整性",
                problem=f"未在提取文本中明显识别到“{kw}”相关章节。",
                suggestion=f"建议核对论文是否设置了规范的“{kw}”部分，或检查该标题是否因排版导致无法识别。",
                evidence="基于全文关键词检索，可能受 PDF 提取效果影响。",
                confidence="low",
            ))

        # 查找可能过短的结论
        for p in doc.pages:
            if "结论" in p.text or "总结" in p.text:
                conclusion_text = p.text[p.text.find("结论"):]
                if 0 < len(conclusion_text) < 350:
                    findings.append(Finding(
                        location=f"第 {p.page_no} 页附近",
                        category="内容完整性",
                        problem="结论或总结部分篇幅可能偏短，对研究贡献、不足和后续工作总结不够充分。",
                        suggestion="建议补充本文主要工作、实验结论、局限性和未来改进方向。",
                        evidence=truncate(conclusion_text),
                        confidence="medium",
                    ))
                break

        return findings

    def check_figures(self, doc: DocumentData) -> List[Finding]:
        findings: List[Finding] = []
        if not doc.figures:
            return findings

        low_px = int(self.config.get("figure_low_resolution_px", 650))
        for fig in doc.figures:
            if fig.width_px and fig.height_px and min(fig.width_px, fig.height_px) < low_px:
                findings.append(Finding(
                    location=f"第 {fig.page_no} 页，图片 {fig.index}",
                    category="图表清晰度",
                    problem=f"检测到图片像素尺寸较小（{fig.width_px}×{fig.height_px}），可能存在清晰度不足问题。",
                    suggestion="建议替换为更高分辨率图片，导出矢量图或提高仿真图 DPI。",
                    evidence=f"图片尺寸：{fig.width_px}×{fig.height_px}px",
                    confidence="medium",
                ))

        # 检查图像尺寸差异很大，可能对应仿真图大小不统一
        areas = [f.width_px * f.height_px for f in doc.figures if f.width_px and f.height_px]
        if len(areas) >= 4:
            avg_area = mean(areas)
            small_count = sum(1 for a in areas if a < avg_area * self.config.get("figure_size_variation_ratio", 0.55))
            if small_count >= 2:
                findings.append(Finding(
                    location="全文图表",
                    category="图表排版",
                    problem="检测到多张图片尺寸相对全文平均图像面积偏小，可能存在图表大小不统一的问题。",
                    suggestion="建议统一仿真图宽度、坐标轴字体、图例字号和图片导出比例。",
                    evidence=f"共检测到 {len(areas)} 张图片，其中 {small_count} 张面积明显偏小。",
                    confidence="medium",
                ))

        return findings

    def check_captions_and_references(self, doc: DocumentData) -> List[Finding]:
        findings: List[Finding] = []
        figure_caption_pattern = re.compile(r"(图\s*\d+|Fig\.?\s*\d+|Figure\s*\d+)", re.IGNORECASE)
        table_caption_pattern = re.compile(r"(表\s*\d+|Table\s*\d+)", re.IGNORECASE)

        all_text = doc.full_text
        figures = figure_caption_pattern.findall(all_text)
        tables = table_caption_pattern.findall(all_text)

        # 中英文图题混用
        if figures:
            has_cn = any("图" in x for x in figures)
            has_en = any(("Fig" in x or "Figure" in x) for x in figures)
            if has_cn and has_en:
                findings.append(Finding(
                    location="全文图题",
                    category="图表编号格式",
                    problem="检测到图题编号可能存在中英文格式混用。",
                    suggestion="建议全文统一使用一种图题编号格式，例如中文论文统一为“图 1-1”。",
                    evidence=", ".join(figures[:8]),
                    confidence="medium",
                ))

        if tables:
            has_cn = any("表" in x for x in tables)
            has_en = any("Table" in x for x in tables)
            if has_cn and has_en:
                findings.append(Finding(
                    location="全文表题",
                    category="表格编号格式",
                    problem="检测到表题编号可能存在中英文格式混用。",
                    suggestion="建议全文统一表题编号格式，并检查表题是否置于表格上方。",
                    evidence=", ".join(tables[:8]),
                    confidence="medium",
                ))

        # 图表只出现一次：可能是有图题但正文没有引用，或正文引用但没有图题
        counts = Counter(standardize_caption(x) for x in figures + tables)
        rare = [k for k, v in counts.items() if v == 1]
        if len(rare) >= 3:
            findings.append(Finding(
                location="全文图表引用",
                category="图表引用",
                problem="部分图表编号在全文中只出现一次，可能存在正文未引用图表或图题编号未统一的问题。",
                suggestion="建议逐一核对图表是否在正文中被解释和引用，避免只放图不分析。",
                evidence=", ".join(rare[:10]),
                confidence="low",
            ))

        return findings

    def check_abbreviations(self, doc: DocumentData) -> List[Finding]:
        text = doc.full_text
        abbreviations = self.config.get("abbreviations") or []
        findings: List[Finding] = []

        for abbr in abbreviations:
            pattern = re.compile(rf"\b{re.escape(abbr)}\b")
            match = pattern.search(text)
            if not match:
                continue

            before = text[max(0, match.start() - 120):match.start()]
            after = text[match.start():min(len(text), match.start() + 120)]
            context = before + after

            # 常见首次定义格式：Full Name (ABBR)
            defined_before = re.search(rf"[A-Za-z][A-Za-z \-/]{{3,80}}\(\s*{re.escape(abbr)}\s*\)", context)
            defined_after = re.search(rf"{re.escape(abbr)}\s*\(\s*[A-Za-z][A-Za-z \-/]{{3,80}}\)", context)
            if not (defined_before or defined_after):
                page_no = locate_page(doc, match.start())
                findings.append(Finding(
                    location=f"第 {page_no} 页附近",
                    category="缩写规范",
                    problem=f"缩写“{abbr}”首次出现附近未检测到完整英文名称解释。",
                    suggestion=f"建议在首次出现时写成“完整英文名称（{abbr}）”或“{abbr}（完整英文名称）”。",
                    evidence=truncate(context),
                    confidence="low",
                ))

        return findings

    def check_formula_symbols(self, doc: DocumentData) -> List[Finding]:
        findings: List[Finding] = []
        text = doc.full_text

        formula_blocks = re.findall(
            r"(\$[^$]{3,}\$|\\begin\{equation\}.*?\\end\{equation\}|\\\[[\s\S]*?\\\])",
            text,
            flags=re.DOTALL,
        )
        if not formula_blocks:
            return findings

        # 只抽取比较像变量的单字母或带下标变量，避免过度复杂
        symbol_pattern = re.compile(r"\\?[a-zA-Z](?:_\{?[a-zA-Z0-9]+\}?|\^[a-zA-Z0-9]+)?")
        candidates = []
        for block in formula_blocks[:80]:
            candidates.extend(symbol_pattern.findall(block))

        stop = {"log", "exp", "sin", "cos", "tan", "min", "max", "sum", "frac", "left", "right", "begin", "end"}
        symbols = []
        for s in candidates:
            clean = s.replace("\\", "")
            if clean.lower() not in stop and len(clean) <= 8:
                symbols.append(clean)

        common = [s for s, c in Counter(symbols).most_common(12) if c >= 2]
        risky = []
        for s in common:
            # 粗略判断是否出现“s 表示 / where s / 其中 s”等解释
            explain_patterns = [
                rf"{re.escape(s)}\s*(表示|为|是| denotes| represents| is )",
                rf"(其中|式中|where)\s*.{{0,40}}{re.escape(s)}",
            ]
            if not any(re.search(p, text, flags=re.IGNORECASE) for p in explain_patterns):
                risky.append(s)

        if risky:
            findings.append(Finding(
                location="全文公式",
                category="符号解释",
                problem="部分高频公式符号未检测到明显解释，可能存在变量定义不完整的问题。",
                suggestion="建议在公式后用“其中……”统一解释变量含义、单位和取值范围，并检查符号前后一致性。",
                evidence="疑似需核对符号：" + ", ".join(risky[:10]),
                confidence="low",
            ))

        return findings

    def check_language_surface(self, doc: DocumentData) -> List[Finding]:
        findings: List[Finding] = []

        weak_words = ["很好的", "非常好", "大量的", "许多的", "显著地提高", "本文做了", "本文进行了相关研究"]
        repeated_punctuation = re.compile(r"[，。；、,.]{2,}")

        for p in doc.pages:
            if repeated_punctuation.search(p.text):
                findings.append(Finding(
                    location=f"第 {p.page_no} 页附近",
                    category="语言表达",
                    problem="检测到连续标点或标点使用异常，可能存在录入或排版问题。",
                    suggestion="建议检查该页标点符号，保持中文论文标点规范。",
                    evidence=truncate(repeated_punctuation.search(p.text).group(0)),
                    confidence="medium",
                ))
                break

        for word in weak_words:
            for p in doc.pages:
                if word in p.text:
                    idx = p.text.find(word)
                    findings.append(Finding(
                        location=f"第 {p.page_no} 页附近",
                        category="表达严谨性",
                        problem=f"检测到表述“{word}”可能偏口语化或评价性较强。",
                        suggestion="建议改为更客观、可量化的学术表达，并尽量结合实验数据或文献依据。",
                        evidence=truncate(p.text[max(0, idx - 60):idx + 100]),
                        confidence="low",
                    ))
                    return findings

        return findings

    def check_reference_section(self, doc: DocumentData) -> List[Finding]:
        text = doc.full_text
        findings: List[Finding] = []

        citation_square = len(re.findall(r"\[\d+\]", text))
        citation_author_year = len(re.findall(r"\([A-Z][A-Za-z]+,\s*\d{4}\)", text))
        if citation_square > 5 and citation_author_year > 3:
            findings.append(Finding(
                location="全文参考文献引用",
                category="参考文献格式",
                problem="检测到数字编号制和作者—年份制引用可能混用。",
                suggestion="建议根据学校模板统一参考文献引用格式。",
                evidence=f"数字编号引用约 {citation_square} 处，作者—年份式引用约 {citation_author_year} 处。",
                confidence="medium",
            ))

        if "参考文献" not in text and "References" not in text:
            findings.append(Finding(
                location="全文末尾",
                category="参考文献",
                problem="未在文本中明显识别到参考文献章节。",
                suggestion="建议核对论文是否包含规范的参考文献部分，并检查 PDF 文本提取是否完整。",
                evidence="未检索到“参考文献”或“References”。",
                confidence="low",
            ))

        return findings


def locate_page(doc: DocumentData, global_char_index: int) -> int:
    # 根据 full_text 拼接顺序粗略定位页码
    count = 0
    for p in doc.pages:
        block = f"[第 {p.page_no} 页]\n{p.text}\n\n"
        count += len(block)
        if count >= global_char_index:
            return p.page_no
    return doc.pages[-1].page_no if doc.pages else 1


def standardize_caption(x: str) -> str:
    x = x.strip().lower().replace("figure", "fig").replace(" ", "")
    return x


def truncate(text: str, n: int = 160) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text[:n] + ("..." if len(text) > n else "")
