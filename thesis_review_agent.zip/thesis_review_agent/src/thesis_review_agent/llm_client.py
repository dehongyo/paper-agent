from __future__ import annotations

import os
from typing import Optional

from dotenv import load_dotenv


class LLMClient:
    def __init__(self, model: Optional[str] = None):
        load_dotenv()
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.base_url = os.getenv("OPENAI_BASE_URL") or None
        self.model = model or os.getenv("LLM_MODEL") or "gpt-4o-mini"

    @property
    def available(self) -> bool:
        return bool(self.api_key)

    def complete(self, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        if not self.available:
            return ""

        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("请先安装 openai：pip install openai") from exc

        client = OpenAI(api_key=self.api_key, base_url=self.base_url)

        resp = client.chat.completions.create(
            model=self.model,
            temperature=temperature,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        return resp.choices[0].message.content or ""
