from __future__ import annotations

import re
from pathlib import Path
from typing import List

from .models import Finding, ReviewResult, DocumentData


def findings_to_markdown(findings: List[Finding]) -> str:
    if not findings:
        return "未发现明显规则问题。"

    lines = [
        "| 位置 | 问题类型 | 具体问题 | 修改建议 | 证据 | 置信度 |",
        "|---|---|---|---|---|---|",
    ]
    lines.extend(f.to_markdown_row() for f in findings)
    return "\n".join(lines)


def build_report(
    doc: DocumentData,
    result: ReviewResult,
    template_path: str | None = None,
) -> str:
    title = "# 硕士论文评审辅助报告\n"
    meta = [
        f"- 论文文件：`{doc.path}`",
        f"- 文件类型：{doc.file_type}",
        f"- 识别页数：{len(doc.pages)}",
        f"- 识别图片数：{len(doc.figures)}",
    ]
    if template_path:
        meta.append(f"- 评审模板：`{template_path}`")

    parts = [title, "\n".join(meta), "\n---\n"]

    if result.raw_llm_text:
        parts.append("## LLM 综合评审意见\n")
        parts.append(result.raw_llm_text)
        parts.append("\n---\n")

    parts.append("## 规则检查结果\n")
    parts.append(findings_to_markdown(result.rule_findings))

    parts.append("\n\n## 使用说明\n")
    parts.append(
        "以上结果由规则检查和大模型辅助生成。低置信度问题通常表示“疑似问题”，需要结合论文原文人工核对。"
    )

    return "\n\n".join(parts)


def save_report(markdown: str, output_path: str) -> None:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(markdown, encoding="utf-8")


def parse_llm_findings(raw_text: str) -> List[Finding]:
    """保留扩展接口：后续可把 LLM 表格解析成结构化 Finding。"""
    return []
